declare module 'remark'

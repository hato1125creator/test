declare module '@mapbox/rehype-prism'

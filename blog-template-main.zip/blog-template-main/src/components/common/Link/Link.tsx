import NextLink from 'next/link';

export const Link = NextLink;

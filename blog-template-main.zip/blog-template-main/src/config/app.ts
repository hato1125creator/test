export const ROOT_URL = process.env.NEXT_PUBLIC_ROOT_URL as string;
export const SITE_NAME = process.env.NEXT_PUBLIC_SITE_NAME as string;

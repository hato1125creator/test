import { About } from '@/components/pages/about';

const View: React.VFC = () => <About />;

export default View;
